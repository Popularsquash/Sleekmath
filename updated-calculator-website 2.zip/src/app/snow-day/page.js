import React from 'react';
import SnowDayCalculator from '@/components/calculators/SnowDayCalculator';

export default function SnowDayPage() {
  return <SnowDayCalculator />;
}
