'use client';

import ScientificCalculator from '@/components/calculators/ScientificCalculator';
import Link from 'next/link';

export default function ScientificPage() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      <div className="lg:col-span-8 lg:col-start-3">
        <ScientificCalculator />
      </div>
    </div>
  );
}
