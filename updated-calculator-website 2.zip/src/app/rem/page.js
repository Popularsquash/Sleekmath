import React from 'react';
import REMCalculator from '@/components/calculators/REMCalculator';

export default function REMPage() {
  return <REMCalculator />;
}
