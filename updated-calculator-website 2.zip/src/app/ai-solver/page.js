'use client';

import { useState } from 'react';

export default function AISolverPage() {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate AI processing
    setTimeout(() => {
      // This is a placeholder for actual AI integration
      // In a real implementation, this would call an API like OpenAI or Wolfram Alpha
      const demoResults = {
        query: query,
        solution: `Solution for "${query}"`,
        steps: [
          "Step 1: Analyze the problem",
          "Step 2: Apply relevant formulas",
          "Step 3: Calculate the result"
        ],
        result: Math.random() * 100 > 50 ? 
          "The answer is approximately 42.7" : 
          "This equation can be solved by factoring: x = 2 or x = -3"
      };
      
      setResult(demoResults);
      setLoading(false);
    }, 1500);
  };

  return (
    <div className="calculator-container max-w-lg">
      <h2 className="calculator-title">AI Math Solver</h2>
      
      <form onSubmit={handleSubmit} className="mb-6">
        <div className="mb-4">
          <label className="block text-gray-300 mb-2" htmlFor="query">
            Enter your math problem
          </label>
          <textarea
            id="query"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full p-3 bg-[#2d2d2d] text-white rounded border border-[#444] focus:border-[#00FFFF] focus:outline-none min-h-[100px]"
            placeholder="E.g., Solve x^2 - 5x + 6 = 0 or Calculate the integral of sin(x)"
            required
          />
        </div>
        
        <button
          type="submit"
          disabled={loading}
          className="w-full py-2 px-4 bg-[rgba(57,255,20,0.3)] text-[#39FF14] rounded hover:bg-[rgba(57,255,20,0.4)] transition-colors disabled:opacity-50"
        >
          {loading ? 'Processing...' : 'Solve Problem'}
        </button>
      </form>
      
      {result && (
        <div className="bg-[#1a1a1a] p-4 rounded-lg mb-6">
          <h3 className="text-[#00FFFF] font-medium mb-2">Solution</h3>
          
          <div className="mb-4">
            <div className="text-gray-300 mb-1">Problem:</div>
            <div className="text-white font-mono bg-[#2d2d2d] p-2 rounded">{result.query}</div>
          </div>
          
          <div className="mb-4">
            <div className="text-gray-300 mb-1">Steps:</div>
            <div className="text-white font-mono bg-[#2d2d2d] p-2 rounded">
              {result.steps.map((step, index) => (
                <div key={index} className="py-1">{step}</div>
              ))}
            </div>
          </div>
          
          <div>
            <div className="text-gray-300 mb-1">Result:</div>
            <div className="text-[#39FF14] font-mono bg-[#2d2d2d] p-2 rounded">{result.result}</div>
          </div>
        </div>
      )}
      
      <div className="text-sm text-gray-400 mt-4">
        <p className="mb-2">This AI solver can help with:</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>Algebraic equations</li>
          <li>Calculus problems</li>
          <li>Geometry calculations</li>
          <li>Statistics questions</li>
          <li>And more!</li>
        </ul>
        <p className="mt-2">
          <span className="text-[#00FFFF]">Premium feature:</span> For more advanced problems and step-by-step explanations, consider upgrading to our premium plan.
        </p>
      </div>
    </div>
  );
}
