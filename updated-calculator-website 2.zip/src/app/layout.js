import { ThemeProvider } from '@/components/ui/ThemeProvider';
import './globals.css';

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="description" content="SleekMath - A modern, black-themed calculator with advanced functionality" />
        <title>SleekMath - Advanced Calculator</title>
        
        {/* Google AdSense Verification Code - Replace XXXXXXXXXXXXXXXX with your Publisher ID */}
        <script 
          async 
          src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXXXXXXXXXX"
          crossOrigin="anonymous"
        />
      </head>
      <body className="min-h-screen bg-gray-950 text-white">
        <ThemeProvider>
          <div className="container mx-auto px-4 py-8">
            <header className="mb-6">
              <h1 className="text-4xl font-bold text-center text-blue-500 mb-2">
                SleekMath Calculator
              </h1>
              <p className="text-center text-gray-400 mb-4">
                A modern, black-themed calculator with advanced functionality
              </p>
              <nav className="flex flex-wrap justify-center space-x-2 md:space-x-4 mb-6">
                <a href="/" className="text-blue-400 hover:text-blue-300 transition-colors mb-2">Basic</a>
                <a href="/scientific" className="text-blue-400 hover:text-blue-300 transition-colors mb-2">Scientific</a>
                <a href="/financial" className="text-blue-400 hover:text-blue-300 transition-colors mb-2">Financial</a>
                <a href="/bmi" className="text-blue-400 hover:text-blue-300 transition-colors mb-2">BMI</a>
                <a href="/unit-converter" className="text-blue-400 hover:text-blue-300 transition-colors mb-2">Unit Converter</a>
                <a href="/ai-solver" className="text-blue-400 hover:text-blue-300 transition-colors mb-2">AI Solver</a>
                <a href="/rem" className="text-blue-400 hover:text-blue-300 transition-colors mb-2">REM</a>
                <a href="/date-duration" className="text-blue-400 hover:text-blue-300 transition-colors mb-2">Date Duration</a>
                <a href="/snow-day" className="text-blue-400 hover:text-blue-300 transition-colors mb-2">Snow Day</a>
              </nav>
            </header>
            
            <main>
              {children}
            </main>
            
            <footer className="mt-12 pt-6 border-t border-gray-800 text-center text-gray-500">
              <p>© 2025 SleekMath.com. All rights reserved.</p>
              <div className="flex justify-center gap-4 mt-2">
                <a href="/about" className="text-gray-500 hover:text-blue-400">About</a>
                <a href="/privacy" className="text-gray-500 hover:text-blue-400">Privacy</a>
                <a href="/terms" className="text-gray-500 hover:text-blue-400">Terms</a>
              </div>
            </footer>
          </div>
        </ThemeProvider>
      </body>
    </html>
  );
}
