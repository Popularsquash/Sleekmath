import React from 'react';
import DateDurationCalculator from '@/components/calculators/DateDurationCalculator';

export default function DateDurationPage() {
  return <DateDurationCalculator />;
}
