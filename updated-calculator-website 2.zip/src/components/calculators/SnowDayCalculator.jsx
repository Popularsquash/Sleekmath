import React, { useState } from 'react';

export const SnowDayCalculator = () => {
  const [temperature, setTemperature] = useState('');
  const [snowfall, setSnowfall] = useState('');
  const [windSpeed, setWindSpeed] = useState('');
  const [roadCondition, setRoadCondition] = useState('normal');
  const [schoolDistrict, setSchoolDistrict] = useState('average');
  const [result, setResult] = useState(null);

  const calculateSnowDayProbability = () => {
    if (!temperature || !snowfall || !windSpeed) {
      return;
    }

    // Convert inputs to numbers
    const temp = parseFloat(temperature);
    const snow = parseFloat(snowfall);
    const wind = parseFloat(windSpeed);

    // Base probability calculation
    let probability = 0;

    // Temperature factor (colder = higher probability)
    if (temp <= 0) {
      probability += 30;
    } else if (temp <= 10) {
      probability += 20;
    } else if (temp <= 20) {
      probability += 10;
    }

    // Snowfall factor (more snow = higher probability)
    if (snow >= 12) {
      probability += 50;
    } else if (snow >= 8) {
      probability += 40;
    } else if (snow >= 4) {
      probability += 30;
    } else if (snow >= 2) {
      probability += 20;
    } else {
      probability += 10 * (snow / 2);
    }

    // Wind speed factor (higher wind = higher probability)
    if (wind >= 35) {
      probability += 20;
    } else if (wind >= 25) {
      probability += 15;
    } else if (wind >= 15) {
      probability += 10;
    } else if (wind >= 5) {
      probability += 5;
    }

    // Road condition factor
    switch (roadCondition) {
      case 'icy':
        probability += 20;
        break;
      case 'snowy':
        probability += 15;
        break;
      case 'wet':
        probability += 5;
        break;
      default:
        break;
    }

    // School district factor
    switch (schoolDistrict) {
      case 'cautious':
        probability += 10;
        break;
      case 'average':
        break;
      case 'hardy':
        probability -= 10;
        break;
      default:
        break;
    }

    // Cap probability between 0 and 100
    probability = Math.min(100, Math.max(0, probability));

    // Determine result message
    let message = '';
    let color = '';

    if (probability >= 90) {
      message = 'Almost certain snow day! Get your sledding gear ready!';
      color = 'text-green-400';
    } else if (probability >= 70) {
      message = 'Very likely snow day. Prepare for a day off!';
      color = 'text-green-500';
    } else if (probability >= 50) {
      message = 'Good chance of a snow day. Keep an eye on announcements!';
      color = 'text-blue-400';
    } else if (probability >= 30) {
      message = 'Possible snow day, but don\'t get your hopes up too high.';
      color = 'text-yellow-400';
    } else if (probability >= 10) {
      message = 'Small chance of a snow day. Probably still have school.';
      color = 'text-orange-400';
    } else {
      message = 'Very unlikely to be a snow day. Set your alarm!';
      color = 'text-red-400';
    }

    setResult({
      probability: Math.round(probability),
      message,
      color
    });
  };

  return (
    <div className="bg-gray-900 p-6 rounded-lg shadow-lg max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold text-blue-400 mb-6">Snow Day Calculator</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div>
          <label className="block text-gray-300 mb-2">Temperature (°F)</label>
          <input
            type="number"
            value={temperature}
            onChange={(e) => setTemperature(e.target.value)}
            className="w-full bg-gray-800 text-white border border-gray-700 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Enter temperature"
          />
        </div>
        
        <div>
          <label className="block text-gray-300 mb-2">Expected Snowfall (inches)</label>
          <input
            type="number"
            value={snowfall}
            onChange={(e) => setSnowfall(e.target.value)}
            className="w-full bg-gray-800 text-white border border-gray-700 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Enter snowfall"
            step="0.1"
          />
        </div>
        
        <div>
          <label className="block text-gray-300 mb-2">Wind Speed (mph)</label>
          <input
            type="number"
            value={windSpeed}
            onChange={(e) => setWindSpeed(e.target.value)}
            className="w-full bg-gray-800 text-white border border-gray-700 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Enter wind speed"
          />
        </div>
        
        <div>
          <label className="block text-gray-300 mb-2">Road Conditions</label>
          <select
            value={roadCondition}
            onChange={(e) => setRoadCondition(e.target.value)}
            className="w-full bg-gray-800 text-white border border-gray-700 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="normal">Normal</option>
            <option value="wet">Wet</option>
            <option value="snowy">Snowy</option>
            <option value="icy">Icy</option>
          </select>
        </div>
        
        <div>
          <label className="block text-gray-300 mb-2">School District Type</label>
          <select
            value={schoolDistrict}
            onChange={(e) => setSchoolDistrict(e.target.value)}
            className="w-full bg-gray-800 text-white border border-gray-700 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="hardy">Hardy (rarely cancels)</option>
            <option value="average">Average</option>
            <option value="cautious">Cautious (often cancels)</option>
          </select>
        </div>
      </div>
      
      <button
        onClick={calculateSnowDayProbability}
        className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition-colors mb-6 w-full"
      >
        Calculate Snow Day Probability
      </button>
      
      {result && (
        <div className="bg-gray-800 p-6 rounded-lg text-center">
          <div className="mb-4">
            <div className="text-gray-300 mb-2">Snow Day Probability:</div>
            <div className="text-4xl font-bold text-blue-400">{result.probability}%</div>
          </div>
          
          <div className="w-full bg-gray-700 rounded-full h-4 mb-4">
            <div 
              className="bg-blue-500 h-4 rounded-full" 
              style={{ width: `${result.probability}%` }}
            ></div>
          </div>
          
          <p className={`text-xl ${result.color}`}>{result.message}</p>
          
          <div className="mt-6 text-sm text-gray-400">
            <p>Note: This calculator provides an estimate based on typical factors that influence school closings. 
            Actual decisions vary by location and administration.</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default SnowDayCalculator;
