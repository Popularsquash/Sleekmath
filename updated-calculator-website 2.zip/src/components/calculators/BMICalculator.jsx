'use client';

import { useState } from 'react';

export default function BMICalculator() {
  const [weight, setWeight] = useState('70');
  const [height, setHeight] = useState('170');
  const [unit, setUnit] = useState('metric'); // metric or imperial
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState([]);

  const calculateBMI = () => {
    let bmi, category, weightInKg, heightInM;
    
    if (unit === 'metric') {
      weightInKg = parseFloat(weight);
      heightInM = parseFloat(height) / 100; // convert cm to m
      bmi = weightInKg / (heightInM * heightInM);
    } else {
      // Imperial: weight in pounds, height in inches
      const weightInPounds = parseFloat(weight);
      const heightInInches = parseFloat(height);
      bmi = (weightInPounds * 703) / (heightInInches * heightInInches);
      
      // Convert to metric for history
      weightInKg = weightInPounds * 0.453592;
      heightInM = heightInInches * 0.0254;
    }
    
    // Determine BMI category
    if (bmi < 18.5) {
      category = 'Underweight';
    } else if (bmi >= 18.5 && bmi < 25) {
      category = 'Normal weight';
    } else if (bmi >= 25 && bmi < 30) {
      category = 'Overweight';
    } else {
      category = 'Obesity';
    }
    
    const newResult = {
      bmi: bmi.toFixed(1),
      category,
      weight: unit === 'metric' ? `${weight} kg` : `${weight} lb`,
      height: unit === 'metric' ? `${height} cm` : `${height} in`
    };
    
    setResult(newResult);
    
    // Add to history
    const historyItem = `${unit === 'metric' ? `${weight} kg, ${height} cm` : `${weight} lb, ${height} in`} = BMI: ${bmi.toFixed(1)} (${category})`;
    setHistory([...history, historyItem]);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    calculateBMI();
  };

  const clearForm = () => {
    if (unit === 'metric') {
      setWeight('70');
      setHeight('170');
    } else {
      setWeight('154');
      setHeight('67');
    }
    setResult(null);
  };

  const toggleUnit = () => {
    if (unit === 'metric') {
      // Convert metric to imperial
      const weightInPounds = (parseFloat(weight) * 2.20462).toFixed(0);
      const heightInInches = (parseFloat(height) * 0.393701).toFixed(0);
      setWeight(weightInPounds);
      setHeight(heightInInches);
      setUnit('imperial');
    } else {
      // Convert imperial to metric
      const weightInKg = (parseFloat(weight) * 0.453592).toFixed(0);
      const heightInCm = (parseFloat(height) * 2.54).toFixed(0);
      setWeight(weightInKg);
      setHeight(heightInCm);
      setUnit('metric');
    }
    setResult(null);
  };

  return (
    <div className="calculator-container max-w-lg">
      <h2 className="calculator-title">BMI Calculator</h2>
      
      <div className="flex justify-end mb-4">
        <button 
          className={`text-xs px-3 py-1.5 rounded ${unit === 'metric' ? 'bg-[#00FFFF] text-black' : 'bg-[#333] text-white'}`}
          onClick={toggleUnit}
        >
          Metric
        </button>
        <button 
          className={`text-xs px-3 py-1.5 rounded ml-2 ${unit === 'imperial' ? 'bg-[#00FFFF] text-black' : 'bg-[#333] text-white'}`}
          onClick={toggleUnit}
        >
          Imperial
        </button>
      </div>
      
      <form onSubmit={handleSubmit} className="mb-6">
        <div className="mb-4">
          <label className="block text-gray-300 mb-2" htmlFor="weight">
            Weight ({unit === 'metric' ? 'kg' : 'lb'})
          </label>
          <input
            id="weight"
            type="number"
            min="0"
            step="0.1"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            className="w-full p-2 bg-[#2d2d2d] text-white rounded border border-[#444] focus:border-[#00FFFF] focus:outline-none"
            required
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-300 mb-2" htmlFor="height">
            Height ({unit === 'metric' ? 'cm' : 'in'})
          </label>
          <input
            id="height"
            type="number"
            min="0"
            step="0.1"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
            className="w-full p-2 bg-[#2d2d2d] text-white rounded border border-[#444] focus:border-[#00FFFF] focus:outline-none"
            required
          />
        </div>
        
        <div className="flex gap-4">
          <button
            type="submit"
            className="w-full py-2 px-4 bg-[rgba(57,255,20,0.3)] text-[#39FF14] rounded hover:bg-[rgba(57,255,20,0.4)] transition-colors"
          >
            Calculate
          </button>
          <button
            type="button"
            onClick={clearForm}
            className="w-full py-2 px-4 bg-[rgba(157,0,255,0.3)] text-[#9D00FF] rounded hover:bg-[rgba(157,0,255,0.4)] transition-colors"
          >
            Clear
          </button>
        </div>
      </form>
      
      {result && (
        <div className="bg-[#1a1a1a] p-4 rounded-lg mb-6">
          <h3 className="text-[#00FFFF] font-medium mb-2">Your BMI Result</h3>
          <div className="grid grid-cols-2 gap-2">
            <div className="text-gray-300">BMI:</div>
            <div className="text-white font-mono font-bold">{result.bmi}</div>
            
            <div className="text-gray-300">Category:</div>
            <div className="text-[#39FF14] font-mono">{result.category}</div>
            
            <div className="text-gray-300">Weight:</div>
            <div className="text-white font-mono">{result.weight}</div>
            
            <div className="text-gray-300">Height:</div>
            <div className="text-white font-mono">{result.height}</div>
          </div>
          
          <div className="mt-4 text-sm text-gray-400">
            <p>BMI Categories:</p>
            <ul className="mt-1 space-y-1">
              <li>Underweight: BMI less than 18.5</li>
              <li>Normal weight: BMI 18.5 to 24.9</li>
              <li>Overweight: BMI 25 to 29.9</li>
              <li>Obesity: BMI 30 or greater</li>
            </ul>
          </div>
        </div>
      )}
      
      {history.length > 0 && (
        <div className="calculator-history">
          <h3 className="text-sm font-medium mb-2">Calculation History</h3>
          {history.map((item, index) => (
            <div key={index} className="calculator-history-item text-sm">
              {item}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
