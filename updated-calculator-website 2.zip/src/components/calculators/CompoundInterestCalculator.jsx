'use client';

import { useState, useEffect } from 'react';

export default function CompoundInterestCalculator() {
  const [principal, setPrincipal] = useState('10000');
  const [rate, setRate] = useState('5');
  const [time, setTime] = useState('5');
  const [compoundFrequency, setCompoundFrequency] = useState('12'); // Monthly by default
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState([]);

  const frequencies = [
    { value: '1', label: 'Annually' },
    { value: '2', label: 'Semi-Annually' },
    { value: '4', label: 'Quarterly' },
    { value: '12', label: 'Monthly' },
    { value: '26', label: 'Bi-Weekly' },
    { value: '52', label: 'Weekly' },
    { value: '365', label: 'Daily' },
    { value: 'continuous', label: 'Continuously' }
  ];

  const calculateCompoundInterest = () => {
    const p = parseFloat(principal);
    const r = parseFloat(rate) / 100;
    const t = parseFloat(time);
    const n = compoundFrequency === 'continuous' ? 'continuous' : parseFloat(compoundFrequency);
    
    let amount, interest;
    
    if (n === 'continuous') {
      amount = p * Math.exp(r * t);
    } else {
      amount = p * Math.pow(1 + r/n, n * t);
    }
    
    interest = amount - p;
    
    const newResult = {
      amount: amount.toFixed(2),
      interest: interest.toFixed(2),
      principal: p.toFixed(2),
      rate: r * 100,
      time: t,
      compoundFrequency: n === 'continuous' ? 'Continuously' : 
        frequencies.find(f => f.value === compoundFrequency)?.label
    };
    
    setResult(newResult);
    
    // Add to history
    const historyItem = `P: $${p.toFixed(2)}, R: ${(r * 100).toFixed(2)}%, T: ${t} years, ${n === 'continuous' ? 'Continuously' : `${n}x/year`} = $${amount.toFixed(2)}`;
    setHistory([...history, historyItem]);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    calculateCompoundInterest();
  };

  const clearForm = () => {
    setPrincipal('10000');
    setRate('5');
    setTime('5');
    setCompoundFrequency('12');
    setResult(null);
  };

  return (
    <div className="calculator-container max-w-lg">
      <h2 className="calculator-title">Compound Interest Calculator</h2>
      
      <form onSubmit={handleSubmit} className="mb-6">
        <div className="mb-4">
          <label className="block text-gray-300 mb-2" htmlFor="principal">
            Principal Amount ($)
          </label>
          <input
            id="principal"
            type="number"
            min="0"
            step="0.01"
            value={principal}
            onChange={(e) => setPrincipal(e.target.value)}
            className="w-full p-2 bg-[#2d2d2d] text-white rounded border border-[#444] focus:border-[#00FFFF] focus:outline-none"
            required
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-300 mb-2" htmlFor="rate">
            Annual Interest Rate (%)
          </label>
          <input
            id="rate"
            type="number"
            min="0"
            step="0.01"
            value={rate}
            onChange={(e) => setRate(e.target.value)}
            className="w-full p-2 bg-[#2d2d2d] text-white rounded border border-[#444] focus:border-[#00FFFF] focus:outline-none"
            required
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-300 mb-2" htmlFor="time">
            Time Period (years)
          </label>
          <input
            id="time"
            type="number"
            min="0"
            step="0.01"
            value={time}
            onChange={(e) => setTime(e.target.value)}
            className="w-full p-2 bg-[#2d2d2d] text-white rounded border border-[#444] focus:border-[#00FFFF] focus:outline-none"
            required
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-300 mb-2" htmlFor="compoundFrequency">
            Compound Frequency
          </label>
          <select
            id="compoundFrequency"
            value={compoundFrequency}
            onChange={(e) => setCompoundFrequency(e.target.value)}
            className="w-full p-2 bg-[#2d2d2d] text-white rounded border border-[#444] focus:border-[#00FFFF] focus:outline-none"
          >
            {frequencies.map((freq) => (
              <option key={freq.value} value={freq.value}>
                {freq.label}
              </option>
            ))}
          </select>
        </div>
        
        <div className="flex gap-4">
          <button
            type="submit"
            className="w-full py-2 px-4 bg-[rgba(57,255,20,0.3)] text-[#39FF14] rounded hover:bg-[rgba(57,255,20,0.4)] transition-colors"
          >
            Calculate
          </button>
          <button
            type="button"
            onClick={clearForm}
            className="w-full py-2 px-4 bg-[rgba(157,0,255,0.3)] text-[#9D00FF] rounded hover:bg-[rgba(157,0,255,0.4)] transition-colors"
          >
            Clear
          </button>
        </div>
      </form>
      
      {result && (
        <div className="bg-[#1a1a1a] p-4 rounded-lg mb-6">
          <h3 className="text-[#00FFFF] font-medium mb-2">Results</h3>
          <div className="grid grid-cols-2 gap-2">
            <div className="text-gray-300">Principal:</div>
            <div className="text-white font-mono">${result.principal}</div>
            
            <div className="text-gray-300">Interest Earned:</div>
            <div className="text-[#39FF14] font-mono">${result.interest}</div>
            
            <div className="text-gray-300">Final Amount:</div>
            <div className="text-white font-mono font-bold">${result.amount}</div>
            
            <div className="text-gray-300">Interest Rate:</div>
            <div className="text-white font-mono">{result.rate}%</div>
            
            <div className="text-gray-300">Time Period:</div>
            <div className="text-white font-mono">{result.time} years</div>
            
            <div className="text-gray-300">Compounded:</div>
            <div className="text-white font-mono">{result.compoundFrequency}</div>
          </div>
        </div>
      )}
      
      {history.length > 0 && (
        <div className="calculator-history">
          <h3 className="text-sm font-medium mb-2">Calculation History</h3>
          {history.map((item, index) => (
            <div key={index} className="calculator-history-item text-sm">
              {item}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
