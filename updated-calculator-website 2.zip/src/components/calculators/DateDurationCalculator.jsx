import React, { useState, useEffect } from 'react';

export const DateDurationCalculator = () => {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [includeEndDate, setIncludeEndDate] = useState(true);
  const [result, setResult] = useState(null);
  
  // Set default end date to today
  useEffect(() => {
    const today = new Date();
    const formattedDate = today.toISOString().split('T')[0];
    setEndDate(formattedDate);
  }, []);

  const calculateDuration = () => {
    if (!startDate || !endDate) return;
    
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    if (start > end) {
      setResult({ error: "Start date cannot be after end date" });
      return;
    }
    
    // Calculate the difference in milliseconds
    const diffTime = Math.abs(end - start);
    
    // Calculate days, adding 1 if including end date
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24)) + (includeEndDate ? 1 : 0);
    
    // Calculate years, months, and remaining days
    let years = 0;
    let months = 0;
    let days = diffDays;
    
    // Create a new date object for calculation
    let tempDate = new Date(start);
    
    // Calculate years
    while (true) {
      tempDate.setFullYear(tempDate.getFullYear() + 1);
      if (tempDate > end) {
        tempDate.setFullYear(tempDate.getFullYear() - 1);
        break;
      }
      years++;
    }
    
    // Calculate months
    while (true) {
      tempDate.setMonth(tempDate.getMonth() + 1);
      if (tempDate > end) {
        tempDate.setMonth(tempDate.getMonth() - 1);
        break;
      }
      months++;
    }
    
    // Calculate remaining days
    const remainingDiffTime = Math.abs(end - tempDate);
    days = Math.floor(remainingDiffTime / (1000 * 60 * 60 * 24)) + (includeEndDate ? 1 : 0);
    
    // Calculate weeks and remaining days
    const weeks = Math.floor(diffDays / 7);
    const remainingDays = diffDays % 7;
    
    // Calculate hours, minutes, seconds
    const hours = Math.floor(diffTime / (1000 * 60 * 60));
    const minutes = Math.floor(diffTime / (1000 * 60));
    const seconds = Math.floor(diffTime / 1000);
    
    setResult({
      days: diffDays,
      weeks,
      remainingDays,
      years,
      months,
      days,
      hours,
      minutes,
      seconds
    });
  };

  return (
    <div className="bg-gray-900 p-6 rounded-lg shadow-lg max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold text-blue-400 mb-6">Date Duration Calculator</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <label className="block text-gray-300 mb-2">Start Date</label>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="w-full bg-gray-800 text-white border border-gray-700 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div>
          <label className="block text-gray-300 mb-2">End Date</label>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="w-full bg-gray-800 text-white border border-gray-700 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>
      
      <div className="mb-6">
        <label className="flex items-center text-gray-300">
          <input
            type="checkbox"
            checked={includeEndDate}
            onChange={(e) => setIncludeEndDate(e.target.checked)}
            className="mr-2 h-5 w-5 text-blue-600 rounded focus:ring-blue-500"
          />
          Include end date in calculation
        </label>
      </div>
      
      <button
        onClick={calculateDuration}
        className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition-colors mb-6"
      >
        Calculate Duration
      </button>
      
      {result && result.error ? (
        <div className="p-4 bg-red-900 text-white rounded-lg">
          {result.error}
        </div>
      ) : result && (
        <div className="bg-gray-800 p-6 rounded-lg">
          <h3 className="text-xl text-blue-300 mb-4">Results</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-gray-700 p-4 rounded-lg">
              <p className="text-gray-300 mb-1">Total Days:</p>
              <p className="text-2xl text-blue-400 font-mono">{result.days} days</p>
            </div>
            
            <div className="bg-gray-700 p-4 rounded-lg">
              <p className="text-gray-300 mb-1">Weeks & Days:</p>
              <p className="text-2xl text-blue-400 font-mono">{result.weeks} weeks, {result.remainingDays} days</p>
            </div>
            
            <div className="bg-gray-700 p-4 rounded-lg">
              <p className="text-gray-300 mb-1">Years, Months & Days:</p>
              <p className="text-2xl text-blue-400 font-mono">
                {result.years} years, {result.months} months, {result.days} days
              </p>
            </div>
            
            <div className="bg-gray-700 p-4 rounded-lg">
              <p className="text-gray-300 mb-1">Hours:</p>
              <p className="text-2xl text-blue-400 font-mono">{result.hours} hours</p>
            </div>
            
            <div className="bg-gray-700 p-4 rounded-lg">
              <p className="text-gray-300 mb-1">Minutes:</p>
              <p className="text-2xl text-blue-400 font-mono">{result.minutes} minutes</p>
            </div>
            
            <div className="bg-gray-700 p-4 rounded-lg">
              <p className="text-gray-300 mb-1">Seconds:</p>
              <p className="text-2xl text-blue-400 font-mono">{result.seconds} seconds</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DateDurationCalculator;
