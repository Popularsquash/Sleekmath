'use client';

import { useState, useEffect } from 'react';

export default function BasicCalculator() {
  const [currentOperand, setCurrentOperand] = useState('0');
  const [previousOperand, setPreviousOperand] = useState('');
  const [operation, setOperation] = useState(null);
  const [history, setHistory] = useState([]);
  const [shouldResetScreen, setShouldResetScreen] = useState(false);

  const clear = () => {
    setCurrentOperand('0');
    setPreviousOperand('');
    setOperation(null);
  };

  const deleteNumber = () => {
    if (currentOperand === '0') return;
    if (currentOperand.length === 1) {
      setCurrentOperand('0');
    } else {
      setCurrentOperand(currentOperand.slice(0, -1));
    }
  };

  const appendNumber = (number) => {
    if (shouldResetScreen) {
      setCurrentOperand(number);
      setShouldResetScreen(false);
      return;
    }
    
    if (number === '.' && currentOperand.includes('.')) return;
    if (currentOperand === '0' && number !== '.') {
      setCurrentOperand(number);
    } else {
      setCurrentOperand(currentOperand + number);
    }
  };

  const chooseOperation = (op) => {
    if (currentOperand === '0') return;
    
    if (previousOperand !== '') {
      compute();
    }
    
    setOperation(op);
    setPreviousOperand(currentOperand);
    setShouldResetScreen(true);
  };

  const compute = () => {
    let computation;
    const prev = parseFloat(previousOperand);
    const current = parseFloat(currentOperand);
    
    if (isNaN(prev) || isNaN(current)) return;
    
    switch (operation) {
      case '+':
        computation = prev + current;
        break;
      case '-':
        computation = prev - current;
        break;
      case '×':
        computation = prev * current;
        break;
      case '÷':
        computation = prev / current;
        break;
      case '%':
        computation = (prev * current) / 100;
        break;
      default:
        return;
    }
    
    // Add to history
    const historyItem = `${prev} ${operation} ${current} = ${computation}`;
    setHistory([...history, historyItem]);
    
    setCurrentOperand(String(computation));
    setOperation(null);
    setPreviousOperand('');
  };

  const handleKeyboardInput = (e) => {
    if (e.key >= '0' && e.key <= '9') appendNumber(e.key);
    if (e.key === '.') appendNumber('.');
    if (e.key === '=' || e.key === 'Enter') compute();
    if (e.key === 'Backspace') deleteNumber();
    if (e.key === 'Escape') clear();
    if (e.key === '+') chooseOperation('+');
    if (e.key === '-') chooseOperation('-');
    if (e.key === '*') chooseOperation('×');
    if (e.key === '/') chooseOperation('÷');
    if (e.key === '%') chooseOperation('%');
  };

  useEffect(() => {
    window.addEventListener('keydown', handleKeyboardInput);
    return () => {
      window.removeEventListener('keydown', handleKeyboardInput);
    };
  }, [currentOperand, previousOperand, operation]);

  const getDisplayNumber = (number) => {
    const stringNumber = number.toString();
    const integerDigits = parseFloat(stringNumber.split('.')[0]);
    const decimalDigits = stringNumber.split('.')[1];
    
    let integerDisplay;
    
    if (isNaN(integerDigits)) {
      integerDisplay = '';
    } else {
      integerDisplay = integerDigits.toLocaleString('en', {
        maximumFractionDigits: 0,
      });
    }
    
    if (decimalDigits != null) {
      return `${integerDisplay}.${decimalDigits}`;
    } else {
      return integerDisplay;
    }
  };

  return (
    <div className="calculator-container">
      <h2 className="calculator-title">Basic Calculator</h2>
      <div className="calculator-display">
        <div className="previous-operand">
          {previousOperand} {operation}
        </div>
        <div className="current-operand">{getDisplayNumber(currentOperand)}</div>
      </div>
      
      <div className="calculator-grid">
        <button className="calculator-button clear" onClick={clear}>
          AC
        </button>
        <button className="calculator-button function" onClick={deleteNumber}>
          DEL
        </button>
        <button className="calculator-button function" onClick={() => chooseOperation('%')}>
          %
        </button>
        <button className="calculator-button operation" onClick={() => chooseOperation('÷')}>
          ÷
        </button>
        
        <button className="calculator-button number" onClick={() => appendNumber('7')}>
          7
        </button>
        <button className="calculator-button number" onClick={() => appendNumber('8')}>
          8
        </button>
        <button className="calculator-button number" onClick={() => appendNumber('9')}>
          9
        </button>
        <button className="calculator-button operation" onClick={() => chooseOperation('×')}>
          ×
        </button>
        
        <button className="calculator-button number" onClick={() => appendNumber('4')}>
          4
        </button>
        <button className="calculator-button number" onClick={() => appendNumber('5')}>
          5
        </button>
        <button className="calculator-button number" onClick={() => appendNumber('6')}>
          6
        </button>
        <button className="calculator-button operation" onClick={() => chooseOperation('-')}>
          -
        </button>
        
        <button className="calculator-button number" onClick={() => appendNumber('1')}>
          1
        </button>
        <button className="calculator-button number" onClick={() => appendNumber('2')}>
          2
        </button>
        <button className="calculator-button number" onClick={() => appendNumber('3')}>
          3
        </button>
        <button className="calculator-button operation" onClick={() => chooseOperation('+')}>
          +
        </button>
        
        <button className="calculator-button number" onClick={() => appendNumber('0')}>
          0
        </button>
        <button className="calculator-button number" onClick={() => appendNumber('.')}>
          .
        </button>
        <button className="calculator-button equals" onClick={compute}>
          =
        </button>
      </div>
      
      {history.length > 0 && (
        <div className="calculator-history">
          <h3 className="text-sm font-medium mb-2">History</h3>
          {history.map((item, index) => (
            <div key={index} className="calculator-history-item text-sm">
              {item}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
