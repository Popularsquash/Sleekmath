'use client';

import { useState } from 'react';

export default function UnitConverter() {
  const [fromValue, setFromValue] = useState('1');
  const [fromUnit, setFromUnit] = useState('meter');
  const [toUnit, setToUnit] = useState('foot');
  const [category, setCategory] = useState('length');
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState([]);

  const categories = [
    { value: 'length', label: 'Length' },
    { value: 'weight', label: 'Weight' },
    { value: 'volume', label: 'Volume' },
    { value: 'temperature', label: 'Temperature' },
    { value: 'area', label: 'Area' },
    { value: 'speed', label: 'Speed' }
  ];

  const units = {
    length: [
      { value: 'meter', label: 'Meter (m)' },
      { value: 'kilometer', label: 'Kilometer (km)' },
      { value: 'centimeter', label: 'Centimeter (cm)' },
      { value: 'millimeter', label: 'Millimeter (mm)' },
      { value: 'foot', label: 'Foot (ft)' },
      { value: 'inch', label: 'Inch (in)' },
      { value: 'yard', label: 'Yard (yd)' },
      { value: 'mile', label: 'Mile (mi)' }
    ],
    weight: [
      { value: 'kilogram', label: 'Kilogram (kg)' },
      { value: 'gram', label: 'Gram (g)' },
      { value: 'milligram', label: 'Milligram (mg)' },
      { value: 'pound', label: 'Pound (lb)' },
      { value: 'ounce', label: 'Ounce (oz)' },
      { value: 'ton', label: 'Metric Ton (t)' }
    ],
    volume: [
      { value: 'liter', label: 'Liter (L)' },
      { value: 'milliliter', label: 'Milliliter (mL)' },
      { value: 'cubic_meter', label: 'Cubic Meter (m³)' },
      { value: 'gallon', label: 'Gallon (gal)' },
      { value: 'quart', label: 'Quart (qt)' },
      { value: 'pint', label: 'Pint (pt)' },
      { value: 'cup', label: 'Cup (cup)' },
      { value: 'fluid_ounce', label: 'Fluid Ounce (fl oz)' }
    ],
    temperature: [
      { value: 'celsius', label: 'Celsius (°C)' },
      { value: 'fahrenheit', label: 'Fahrenheit (°F)' },
      { value: 'kelvin', label: 'Kelvin (K)' }
    ],
    area: [
      { value: 'square_meter', label: 'Square Meter (m²)' },
      { value: 'square_kilometer', label: 'Square Kilometer (km²)' },
      { value: 'square_centimeter', label: 'Square Centimeter (cm²)' },
      { value: 'square_foot', label: 'Square Foot (ft²)' },
      { value: 'square_inch', label: 'Square Inch (in²)' },
      { value: 'acre', label: 'Acre (ac)' },
      { value: 'hectare', label: 'Hectare (ha)' }
    ],
    speed: [
      { value: 'meter_per_second', label: 'Meter per Second (m/s)' },
      { value: 'kilometer_per_hour', label: 'Kilometer per Hour (km/h)' },
      { value: 'mile_per_hour', label: 'Mile per Hour (mph)' },
      { value: 'knot', label: 'Knot (kn)' },
      { value: 'foot_per_second', label: 'Foot per Second (ft/s)' }
    ]
  };

  // Conversion factors to SI units
  const conversionFactors = {
    // Length (to meters)
    meter: 1,
    kilometer: 1000,
    centimeter: 0.01,
    millimeter: 0.001,
    foot: 0.3048,
    inch: 0.0254,
    yard: 0.9144,
    mile: 1609.344,
    
    // Weight (to kilograms)
    kilogram: 1,
    gram: 0.001,
    milligram: 0.000001,
    pound: 0.45359237,
    ounce: 0.028349523125,
    ton: 1000,
    
    // Volume (to liters)
    liter: 1,
    milliliter: 0.001,
    cubic_meter: 1000,
    gallon: 3.78541178,
    quart: 0.946352946,
    pint: 0.473176473,
    cup: 0.2365882365,
    fluid_ounce: 0.0295735295625,
    
    // Area (to square meters)
    square_meter: 1,
    square_kilometer: 1000000,
    square_centimeter: 0.0001,
    square_foot: 0.09290304,
    square_inch: 0.00064516,
    acre: 4046.8564224,
    hectare: 10000,
    
    // Speed (to meters per second)
    meter_per_second: 1,
    kilometer_per_hour: 0.277777778,
    mile_per_hour: 0.44704,
    knot: 0.514444444,
    foot_per_second: 0.3048
  };

  const convert = () => {
    const value = parseFloat(fromValue);
    
    if (isNaN(value)) {
      setResult({ error: 'Please enter a valid number' });
      return;
    }
    
    let convertedValue;
    
    // Special case for temperature
    if (category === 'temperature') {
      if (fromUnit === 'celsius' && toUnit === 'fahrenheit') {
        convertedValue = (value * 9/5) + 32;
      } else if (fromUnit === 'celsius' && toUnit === 'kelvin') {
        convertedValue = value + 273.15;
      } else if (fromUnit === 'fahrenheit' && toUnit === 'celsius') {
        convertedValue = (value - 32) * 5/9;
      } else if (fromUnit === 'fahrenheit' && toUnit === 'kelvin') {
        convertedValue = (value - 32) * 5/9 + 273.15;
      } else if (fromUnit === 'kelvin' && toUnit === 'celsius') {
        convertedValue = value - 273.15;
      } else if (fromUnit === 'kelvin' && toUnit === 'fahrenheit') {
        convertedValue = (value - 273.15) * 9/5 + 32;
      } else {
        convertedValue = value; // Same unit
      }
    } else {
      // For other categories, convert to SI unit first, then to target unit
      const valueInSI = value * conversionFactors[fromUnit];
      convertedValue = valueInSI / conversionFactors[toUnit];
    }
    
    const fromUnitLabel = units[category].find(u => u.value === fromUnit)?.label;
    const toUnitLabel = units[category].find(u => u.value === toUnit)?.label;
    
    setResult({
      value: convertedValue.toFixed(6),
      fromValue: value,
      fromUnit: fromUnitLabel,
      toUnit: toUnitLabel
    });
    
    // Add to history
    const historyItem = `${value} ${fromUnitLabel} = ${convertedValue.toFixed(6)} ${toUnitLabel}`;
    setHistory([...history, historyItem]);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    convert();
  };

  const clearForm = () => {
    setFromValue('1');
    setResult(null);
  };

  const handleCategoryChange = (e) => {
    const newCategory = e.target.value;
    setCategory(newCategory);
    setFromUnit(units[newCategory][0].value);
    setToUnit(units[newCategory][1].value);
    setResult(null);
  };

  const swapUnits = () => {
    setFromUnit(toUnit);
    setToUnit(fromUnit);
    setResult(null);
  };

  return (
    <div className="calculator-container max-w-lg">
      <h2 className="calculator-title">Unit Converter</h2>
      
      <form onSubmit={handleSubmit} className="mb-6">
        <div className="mb-4">
          <label className="block text-gray-300 mb-2" htmlFor="category">
            Category
          </label>
          <select
            id="category"
            value={category}
            onChange={handleCategoryChange}
            className="w-full p-2 bg-[#2d2d2d] text-white rounded border border-[#444] focus:border-[#00FFFF] focus:outline-none"
          >
            {categories.map((cat) => (
              <option key={cat.value} value={cat.value}>
                {cat.label}
              </option>
            ))}
          </select>
        </div>
        
        <div className="mb-4">
          <label className="block text-gray-300 mb-2" htmlFor="fromValue">
            Value
          </label>
          <input
            id="fromValue"
            type="number"
            step="any"
            value={fromValue}
            onChange={(e) => setFromValue(e.target.value)}
            className="w-full p-2 bg-[#2d2d2d] text-white rounded border border-[#444] focus:border-[#00FFFF] focus:outline-none"
            required
          />
        </div>
        
        <div className="grid grid-cols-5 gap-4 mb-4">
          <div className="col-span-2">
            <label className="block text-gray-300 mb-2" htmlFor="fromUnit">
              From
            </label>
            <select
              id="fromUnit"
              value={fromUnit}
              onChange={(e) => setFromUnit(e.target.value)}
              className="w-full p-2 bg-[#2d2d2d] text-white rounded border border-[#444] focus:border-[#00FFFF] focus:outline-none"
            >
              {units[category].map((unit) => (
                <option key={unit.value} value={unit.value}>
                  {unit.label}
                </option>
              ))}
            </select>
          </div>
          
          <div className="flex items-end justify-center">
            <button
              type="button"
              onClick={swapUnits}
              className="p-2 bg-[#333] text-white rounded hover:bg-[#444] transition-colors"
            >
              ⇄
            </button>
          </div>
          
          <div className="col-span-2">
            <label className="block text-gray-300 mb-2" htmlFor="toUnit">
              To
            </label>
            <select
              id="toUnit"
              value={toUnit}
              onChange={(e) => setToUnit(e.target.value)}
              className="w-full p-2 bg-[#2d2d2d] text-white rounded border border-[#444] focus:border-[#00FFFF] focus:outline-none"
            >
              {units[category].map((unit) => (
                <option key={unit.value} value={unit.value}>
                  {unit.label}
                </option>
              ))}
            </select>
          </div>
        </div>
        
        <div className="flex gap-4">
          <button
            type="submit"
            className="w-full py-2 px-4 bg-[rgba(57,255,20,0.3)] text-[#39FF14] rounded hover:bg-[rgba(57,255,20,0.4)] transition-colors"
          >
            Convert
          </button>
          <button
            type="button"
            onClick={clearForm}
            className="w-full py-2 px-4 bg-[rgba(157,0,255,0.3)] text-[#9D00FF] rounded hover:bg-[rgba(157,0,255,0.4)] transition-colors"
          >
            Clear
          </button>
        </div>
      </form>
      
      {result && !result.error && (
        <div className="bg-[#1a1a1a] p-4 rounded-lg mb-6">
          <h3 className="text-[#00FFFF] font-medium mb-2">Conversion Result</h3>
          <div className="text-center">
            <div className="text-lg text-white font-mono">
              {result.fromValue} {result.fromUnit.split(' ')[0]}
            </div>
            <div className="text-gray-400 my-1">=</div>
            <div className="text-2xl text-[#39FF14] font-mono font-bold">
              {result.value} {result.toUnit.split(' ')[0]}
            </div>
          </div>
        </div>
      )}
      
      {result && result.error && (
        <div className="bg-[#1a1a1a] p-4 rounded-lg mb-6 text-red-400">
          {result.error}
        </div>
      )}
      
      {history.length > 0 && (
        <div className="calculator-history">
          <h3 className="text-sm font-medium mb-2">Conversion History</h3>
          {history.map((item, index) => (
            <div key={index} className="calculator-history-item text-sm">
              {item}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
