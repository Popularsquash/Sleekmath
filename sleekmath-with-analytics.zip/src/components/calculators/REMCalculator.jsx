import React, { useState } from 'react';

export const REMCalculator = () => {
  const [pixelValue, setPixelValue] = useState('');
  const [baseSize, setBaseSize] = useState('16');
  const [remValue, setRemValue] = useState('');
  const [pixelFromRem, setPixelFromRem] = useState('');
  const [remInput, setRemInput] = useState('');

  const calculateREM = () => {
    if (pixelValue && baseSize) {
      const rem = parseFloat(pixelValue) / parseFloat(baseSize);
      setRemValue(rem.toFixed(4));
    }
  };

  const calculatePixels = () => {
    if (remInput && baseSize) {
      const pixels = parseFloat(remInput) * parseFloat(baseSize);
      setPixelFromRem(pixels.toFixed(0));
    }
  };

  return (
    <div className="bg-gray-900 p-6 rounded-lg shadow-lg max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold text-blue-400 mb-6">REM Calculator</h2>
      
      <div className="mb-8">
        <h3 className="text-xl text-blue-300 mb-4">Pixels to REM</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-gray-300 mb-2">Pixel Value (px)</label>
            <input
              type="number"
              value={pixelValue}
              onChange={(e) => setPixelValue(e.target.value)}
              className="w-full bg-gray-800 text-white border border-gray-700 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter pixel value"
            />
          </div>
          <div>
            <label className="block text-gray-300 mb-2">Base Font Size (px)</label>
            <input
              type="number"
              value={baseSize}
              onChange={(e) => setBaseSize(e.target.value)}
              className="w-full bg-gray-800 text-white border border-gray-700 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Default: 16px"
            />
          </div>
        </div>
        <button
          onClick={calculateREM}
          className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition-colors"
        >
          Calculate REM
        </button>
        {remValue && (
          <div className="mt-4 p-4 bg-gray-800 rounded-lg">
            <p className="text-gray-300">Result:</p>
            <p className="text-2xl text-blue-400 font-mono">{remValue}rem</p>
          </div>
        )}
      </div>
      
      <div className="border-t border-gray-700 pt-8">
        <h3 className="text-xl text-blue-300 mb-4">REM to Pixels</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-gray-300 mb-2">REM Value</label>
            <input
              type="number"
              value={remInput}
              onChange={(e) => setRemInput(e.target.value)}
              className="w-full bg-gray-800 text-white border border-gray-700 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter REM value"
              step="0.1"
            />
          </div>
          <div>
            <label className="block text-gray-300 mb-2">Base Font Size (px)</label>
            <input
              type="number"
              value={baseSize}
              onChange={(e) => setBaseSize(e.target.value)}
              className="w-full bg-gray-800 text-white border border-gray-700 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Default: 16px"
            />
          </div>
        </div>
        <button
          onClick={calculatePixels}
          className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition-colors"
        >
          Calculate Pixels
        </button>
        {pixelFromRem && (
          <div className="mt-4 p-4 bg-gray-800 rounded-lg">
            <p className="text-gray-300">Result:</p>
            <p className="text-2xl text-blue-400 font-mono">{pixelFromRem}px</p>
          </div>
        )}
      </div>
      
      <div className="mt-8 bg-gray-800 p-4 rounded-lg">
        <h3 className="text-lg text-blue-300 mb-2">What is REM?</h3>
        <p className="text-gray-300">
          REM (Root EM) is a unit of measurement in CSS that's relative to the font size of the root element (html).
          By default, 1rem equals 16px in most browsers. REM units are useful for creating scalable and accessible designs.
        </p>
      </div>
    </div>
  );
};

export default REMCalculator;
