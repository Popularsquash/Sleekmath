'use client';

import { useState, useEffect } from 'react';

export default function ScientificCalculator() {
  const [currentOperand, setCurrentOperand] = useState('0');
  const [previousOperand, setPreviousOperand] = useState('');
  const [operation, setOperation] = useState(null);
  const [history, setHistory] = useState([]);
  const [shouldResetScreen, setShouldResetScreen] = useState(false);
  const [degreeMode, setDegreeMode] = useState(true); // true for degrees, false for radians

  const clear = () => {
    setCurrentOperand('0');
    setPreviousOperand('');
    setOperation(null);
  };

  const deleteNumber = () => {
    if (currentOperand === '0') return;
    if (currentOperand.length === 1) {
      setCurrentOperand('0');
    } else {
      setCurrentOperand(currentOperand.slice(0, -1));
    }
  };

  const appendNumber = (number) => {
    if (shouldResetScreen) {
      setCurrentOperand(number);
      setShouldResetScreen(false);
      return;
    }
    
    if (number === '.' && currentOperand.includes('.')) return;
    if (currentOperand === '0' && number !== '.') {
      setCurrentOperand(number);
    } else {
      setCurrentOperand(currentOperand + number);
    }
  };

  const chooseOperation = (op) => {
    if (currentOperand === '0') return;
    
    if (previousOperand !== '') {
      compute();
    }
    
    setOperation(op);
    setPreviousOperand(currentOperand);
    setShouldResetScreen(true);
  };

  const compute = () => {
    let computation;
    const prev = parseFloat(previousOperand);
    const current = parseFloat(currentOperand);
    
    if (isNaN(prev) || isNaN(current)) return;
    
    switch (operation) {
      case '+':
        computation = prev + current;
        break;
      case '-':
        computation = prev - current;
        break;
      case '×':
        computation = prev * current;
        break;
      case '÷':
        if (current === 0) {
          setCurrentOperand('Error');
          setPreviousOperand('');
          setOperation(null);
          return;
        }
        computation = prev / current;
        break;
      case '%':
        computation = (prev * current) / 100;
        break;
      case 'y^x':
        computation = Math.pow(prev, current);
        break;
      default:
        return;
    }
    
    // Add to history
    const historyItem = `${prev} ${operation} ${current} = ${computation}`;
    setHistory([...history, historyItem]);
    
    setCurrentOperand(String(computation));
    setOperation(null);
    setPreviousOperand('');
  };

  const performFunction = (func) => {
    const current = parseFloat(currentOperand);
    let result;

    switch (func) {
      case 'sin':
        result = degreeMode ? 
          Math.sin(current * Math.PI / 180) : 
          Math.sin(current);
        break;
      case 'cos':
        result = degreeMode ? 
          Math.cos(current * Math.PI / 180) : 
          Math.cos(current);
        break;
      case 'tan':
        result = degreeMode ? 
          Math.tan(current * Math.PI / 180) : 
          Math.tan(current);
        break;
      case 'log':
        result = Math.log10(current);
        break;
      case 'ln':
        result = Math.log(current);
        break;
      case 'sqrt':
        result = Math.sqrt(current);
        break;
      case 'x^2':
        result = Math.pow(current, 2);
        break;
      case '1/x':
        if (current === 0) {
          setCurrentOperand('Error');
          return;
        }
        result = 1 / current;
        break;
      case 'π':
        result = Math.PI;
        break;
      case 'e':
        result = Math.E;
        break;
      case '+/-':
        result = current * -1;
        break;
      default:
        return;
    }

    // Add to history
    const historyItem = `${func}(${current}) = ${result}`;
    setHistory([...history, historyItem]);
    
    setCurrentOperand(String(result));
    setShouldResetScreen(true);
  };

  const toggleDegreeMode = () => {
    setDegreeMode(!degreeMode);
  };

  const handleKeyboardInput = (e) => {
    if (e.key >= '0' && e.key <= '9') appendNumber(e.key);
    if (e.key === '.') appendNumber('.');
    if (e.key === '=' || e.key === 'Enter') compute();
    if (e.key === 'Backspace') deleteNumber();
    if (e.key === 'Escape') clear();
    if (e.key === '+') chooseOperation('+');
    if (e.key === '-') chooseOperation('-');
    if (e.key === '*') chooseOperation('×');
    if (e.key === '/') chooseOperation('÷');
    if (e.key === '%') chooseOperation('%');
    if (e.key === '^') chooseOperation('y^x');
  };

  useEffect(() => {
    window.addEventListener('keydown', handleKeyboardInput);
    return () => {
      window.removeEventListener('keydown', handleKeyboardInput);
    };
  }, [currentOperand, previousOperand, operation]);

  const getDisplayNumber = (number) => {
    const stringNumber = number.toString();
    const integerDigits = parseFloat(stringNumber.split('.')[0]);
    const decimalDigits = stringNumber.split('.')[1];
    
    let integerDisplay;
    
    if (isNaN(integerDigits)) {
      integerDisplay = '';
    } else {
      integerDisplay = integerDigits.toLocaleString('en', {
        maximumFractionDigits: 0,
      });
    }
    
    if (decimalDigits != null) {
      return `${integerDisplay}.${decimalDigits}`;
    } else {
      return integerDisplay;
    }
  };

  return (
    <div className="calculator-container">
      <h2 className="calculator-title">Scientific Calculator</h2>
      <div className="calculator-display">
        <div className="previous-operand">
          {previousOperand} {operation}
        </div>
        <div className="current-operand">{getDisplayNumber(currentOperand)}</div>
      </div>
      
      <div className="flex justify-end mb-2">
        <button 
          className={`text-xs px-2 py-1 rounded ${degreeMode ? 'bg-[#00FFFF] text-black' : 'bg-[#333] text-white'}`}
          onClick={toggleDegreeMode}
        >
          DEG
        </button>
        <button 
          className={`text-xs px-2 py-1 rounded ml-2 ${!degreeMode ? 'bg-[#00FFFF] text-black' : 'bg-[#333] text-white'}`}
          onClick={toggleDegreeMode}
        >
          RAD
        </button>
      </div>
      
      <div className="grid grid-cols-5 gap-1 mb-2">
        <button className="calculator-button function" onClick={() => performFunction('sin')}>
          sin
        </button>
        <button className="calculator-button function" onClick={() => performFunction('cos')}>
          cos
        </button>
        <button className="calculator-button function" onClick={() => performFunction('tan')}>
          tan
        </button>
        <button className="calculator-button function" onClick={() => performFunction('log')}>
          log
        </button>
        <button className="calculator-button function" onClick={() => performFunction('ln')}>
          ln
        </button>
        
        <button className="calculator-button function" onClick={() => performFunction('x^2')}>
          x²
        </button>
        <button className="calculator-button function" onClick={() => chooseOperation('y^x')}>
          y^x
        </button>
        <button className="calculator-button function" onClick={() => performFunction('sqrt')}>
          √
        </button>
        <button className="calculator-button function" onClick={() => performFunction('1/x')}>
          1/x
        </button>
        <button className="calculator-button function" onClick={() => performFunction('+/-')}>
          ±
        </button>
      </div>
      
      <div className="calculator-grid">
        <button className="calculator-button clear" onClick={clear}>
          AC
        </button>
        <button className="calculator-button function" onClick={deleteNumber}>
          DEL
        </button>
        <button className="calculator-button function" onClick={() => performFunction('π')}>
          π
        </button>
        <button className="calculator-button function" onClick={() => performFunction('e')}>
          e
        </button>
        
        <button className="calculator-button number" onClick={() => appendNumber('7')}>
          7
        </button>
        <button className="calculator-button number" onClick={() => appendNumber('8')}>
          8
        </button>
        <button className="calculator-button number" onClick={() => appendNumber('9')}>
          9
        </button>
        <button className="calculator-button operation" onClick={() => chooseOperation('÷')}>
          ÷
        </button>
        
        <button className="calculator-button number" onClick={() => appendNumber('4')}>
          4
        </button>
        <button className="calculator-button number" onClick={() => appendNumber('5')}>
          5
        </button>
        <button className="calculator-button number" onClick={() => appendNumber('6')}>
          6
        </button>
        <button className="calculator-button operation" onClick={() => chooseOperation('×')}>
          ×
        </button>
        
        <button className="calculator-button number" onClick={() => appendNumber('1')}>
          1
        </button>
        <button className="calculator-button number" onClick={() => appendNumber('2')}>
          2
        </button>
        <button className="calculator-button number" onClick={() => appendNumber('3')}>
          3
        </button>
        <button className="calculator-button operation" onClick={() => chooseOperation('-')}>
          -
        </button>
        
        <button className="calculator-button number" onClick={() => appendNumber('0')}>
          0
        </button>
        <button className="calculator-button number" onClick={() => appendNumber('.')}>
          .
        </button>
        <button className="calculator-button equals" onClick={compute}>
          =
        </button>
        <button className="calculator-button operation" onClick={() => chooseOperation('+')}>
          +
        </button>
      </div>
      
      {history.length > 0 && (
        <div className="calculator-history">
          <h3 className="text-sm font-medium mb-2">History</h3>
          {history.map((item, index) => (
            <div key={index} className="calculator-history-item text-sm">
              {item}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
