import React from 'react';

export default function PrivacyPolicyPage() {
  return (
    <div className="bg-gray-900 p-6 rounded-lg shadow-lg max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-blue-400 mb-6">Privacy Policy</h1>
      
      <p className="text-gray-300 mb-6">
        Last Updated: March 31, 2025
      </p>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">Introduction</h2>
        <p className="text-gray-300 mb-4">
          Welcome to SleekMath ("we," "our," or "us"). We respect your privacy and are committed to protecting your personal information. 
          This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website sleekmath.com, 
          including any other media form, media channel, mobile website, or mobile application related or connected thereto (collectively, the "Site").
        </p>
        <p className="text-gray-300 mb-4">
          Please read this Privacy Policy carefully. If you do not agree with the terms of this Privacy Policy, please do not access the Site.
        </p>
      </section>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">Information We Collect</h2>
        
        <h3 className="text-xl text-blue-200 mb-3">Personal Information</h3>
        <p className="text-gray-300 mb-4">
          We may collect personal information that you voluntarily provide to us when you use our calculators, subscribe to our newsletter, 
          or otherwise contact us. The personal information we may collect includes:
        </p>
        <ul className="list-disc list-inside text-gray-300 space-y-2 ml-4 mb-4">
          <li>Name and email address (if you contact us or subscribe to our newsletter)</li>
          <li>Usage data and preferences</li>
          <li>Any other information you choose to provide</li>
        </ul>
        
        <h3 className="text-xl text-blue-200 mb-3">Automatically Collected Information</h3>
        <p className="text-gray-300 mb-4">
          When you access our Site, we may automatically collect certain information about your device, including:
        </p>
        <ul className="list-disc list-inside text-gray-300 space-y-2 ml-4">
          <li>IP address</li>
          <li>Browser type and version</li>
          <li>Operating system</li>
          <li>Time zone setting and location</li>
          <li>Pages visited and time spent on those pages</li>
          <li>Referring website addresses</li>
        </ul>
      </section>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">How We Use Your Information</h2>
        <p className="text-gray-300 mb-4">
          We may use the information we collect for various purposes, including:
        </p>
        <ul className="list-disc list-inside text-gray-300 space-y-2 ml-4">
          <li>Providing, maintaining, and improving our calculator services</li>
          <li>Responding to your comments, questions, and requests</li>
          <li>Sending you technical notices, updates, and administrative messages</li>
          <li>Monitoring and analyzing trends, usage, and activities in connection with our Site</li>
          <li>Detecting, preventing, and addressing technical issues</li>
          <li>Displaying advertisements based on your interests (see "Advertising" below)</li>
        </ul>
      </section>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">Cookies and Similar Technologies</h2>
        <p className="text-gray-300 mb-4">
          We may use cookies, web beacons, and similar tracking technologies to collect information about your browsing activities on our Site. 
          These technologies help us analyze website traffic, customize content, and deliver targeted advertisements.
        </p>
        <p className="text-gray-300 mb-4">
          You can set your browser to refuse all or some browser cookies or to alert you when cookies are being sent. 
          However, if you disable or refuse cookies, some parts of the Site may become inaccessible or not function properly.
        </p>
      </section>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">Advertising</h2>
        <p className="text-gray-300 mb-4">
          We use third-party advertising companies, such as Google AdSense, to serve advertisements when you visit our Site. 
          These companies may use information about your visits to this and other websites to provide advertisements about goods and services of interest to you.
        </p>
        <p className="text-gray-300 mb-4">
          We do not control these third parties' tracking technologies or how they may be used. If you have questions about an advertisement, 
          you should contact the responsible advertiser directly.
        </p>
      </section>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">Data Security</h2>
        <p className="text-gray-300 mb-4">
          We have implemented measures designed to secure your personal information from accidental loss and from unauthorized access, use, alteration, and disclosure. 
          However, the transmission of information via the internet is not completely secure. Although we do our best to protect your personal information, 
          we cannot guarantee the security of your personal information transmitted to our Site.
        </p>
      </section>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">Children's Privacy</h2>
        <p className="text-gray-300 mb-4">
          Our Site is not intended for children under 13 years of age. We do not knowingly collect personal information from children under 13. 
          If you are a parent or guardian and believe that your child has provided us with personal information, please contact us.
        </p>
      </section>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">Changes to Our Privacy Policy</h2>
        <p className="text-gray-300 mb-4">
          We may update our Privacy Policy from time to time. If we make material changes to how we treat our users' personal information, 
          we will post the new Privacy Policy on this page with a notice that the Privacy Policy has been updated.
        </p>
        <p className="text-gray-300 mb-4">
          The date the Privacy Policy was last revised is identified at the top of the page. You are responsible for periodically visiting our Site and this Privacy Policy to check for any changes.
        </p>
      </section>
      
      <section>
        <h2 className="text-2xl text-blue-300 mb-4">Contact Information</h2>
        <p className="text-gray-300 mb-4">
          If you have any questions or concerns about this Privacy Policy, please contact us at:
        </p>
        <p className="text-blue-400">privacy@sleekmath.com</p>
      </section>
    </div>
  );
}
