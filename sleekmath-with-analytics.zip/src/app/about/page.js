import React from 'react';

export default function AboutPage() {
  return (
    <div className="bg-gray-900 p-6 rounded-lg shadow-lg max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-blue-400 mb-6">About SleekMath</h1>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">Our Mission</h2>
        <p className="text-gray-300 mb-4">
          At SleekMath, our mission is to provide accessible, powerful, and beautifully designed calculation tools for everyone. 
          We believe that mathematics and calculations should be approachable, intuitive, and even enjoyable.
        </p>
        <p className="text-gray-300 mb-4">
          Our sleek, modern calculator suite offers a comprehensive range of tools designed to help students, professionals, 
          and anyone who needs quick, accurate calculations in their daily life.
        </p>
      </section>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">Our Story</h2>
        <p className="text-gray-300 mb-4">
          SleekMath began with a simple idea: calculators should be as elegant as they are functional. 
          Frustrated with clunky, outdated calculator interfaces, our founder set out to create a suite of 
          calculation tools that would combine powerful functionality with modern design principles.
        </p>
        <p className="text-gray-300 mb-4">
          Since our launch, we've been dedicated to expanding our calculator offerings while maintaining our 
          commitment to sleek design, intuitive user experience, and mathematical accuracy.
        </p>
      </section>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">Our Calculators</h2>
        <p className="text-gray-300 mb-4">
          SleekMath offers a diverse range of calculators, from basic arithmetic to specialized tools:
        </p>
        <ul className="list-disc list-inside text-gray-300 space-y-2 ml-4">
          <li>Basic Calculator - For everyday calculations</li>
          <li>Scientific Calculator - For advanced mathematical functions</li>
          <li>Financial Calculator - For compound interest and financial planning</li>
          <li>BMI Calculator - For health and fitness tracking</li>
          <li>Unit Converter - For easy conversion between measurement systems</li>
          <li>REM Calculator - For web developers working with responsive design</li>
          <li>Date Duration Calculator - For calculating time between dates</li>
          <li>Snow Day Calculator - For predicting school closures due to weather</li>
          <li>AI Solver - For complex mathematical problem-solving</li>
        </ul>
      </section>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">Our Technology</h2>
        <p className="text-gray-300 mb-4">
          SleekMath is built using cutting-edge web technologies to ensure speed, accuracy, and a seamless user experience. 
          Our platform is designed to be responsive, working flawlessly across desktop and mobile devices.
        </p>
        <p className="text-gray-300 mb-4">
          We're constantly updating our calculators to improve functionality, add new features, and ensure 
          mathematical precision in all our tools.
        </p>
      </section>
      
      <section>
        <h2 className="text-2xl text-blue-300 mb-4">Contact Us</h2>
        <p className="text-gray-300 mb-4">
          We value your feedback and suggestions. If you have ideas for new calculators, improvements to existing ones, 
          or any questions about SleekMath, please don't hesitate to reach out to us at:
        </p>
        <p className="text-blue-400">contact@sleekmath.com</p>
      </section>
    </div>
  );
}
