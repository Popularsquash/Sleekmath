import React from 'react';

export default function TermsOfServicePage() {
  return (
    <div className="bg-gray-900 p-6 rounded-lg shadow-lg max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-blue-400 mb-6">Terms of Service</h1>
      
      <p className="text-gray-300 mb-6">
        Last Updated: March 31, 2025
      </p>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">1. Acceptance of Terms</h2>
        <p className="text-gray-300 mb-4">
          Welcome to SleekMath. These Terms of Service ("Terms") govern your access to and use of the SleekMath website, 
          including any content, functionality, and services offered on or through sleekmath.com (the "Website").
        </p>
        <p className="text-gray-300 mb-4">
          Please read these Terms carefully before using our Website. By using the Website, you accept and agree to be bound by these Terms. 
          If you do not agree to these Terms, you must not access or use the Website.
        </p>
      </section>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">2. Changes to the Terms</h2>
        <p className="text-gray-300 mb-4">
          We may revise and update these Terms from time to time at our sole discretion. All changes are effective immediately when 
          posted and apply to all access to and use of the Website thereafter.
        </p>
        <p className="text-gray-300 mb-4">
          Your continued use of the Website following the posting of revised Terms means that you accept and agree to the changes. 
          You are expected to check this page periodically so you are aware of any changes, as they are binding on you.
        </p>
      </section>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">3. Accessing the Website</h2>
        <p className="text-gray-300 mb-4">
          We reserve the right to withdraw or amend this Website, and any service or material we provide on the Website, 
          in our sole discretion without notice. We will not be liable if, for any reason, all or any part of the Website 
          is unavailable at any time or for any period.
        </p>
        <p className="text-gray-300 mb-4">
          You are responsible for ensuring that all persons who access the Website through your internet connection are 
          aware of these Terms and comply with them.
        </p>
      </section>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">4. Intellectual Property Rights</h2>
        <p className="text-gray-300 mb-4">
          The Website and its entire contents, features, and functionality (including but not limited to all information, 
          software, text, displays, images, video, and audio, and the design, selection, and arrangement thereof) are owned 
          by SleekMath, its licensors, or other providers of such material and are protected by copyright, trademark, patent, 
          trade secret, and other intellectual property or proprietary rights laws.
        </p>
        <p className="text-gray-300 mb-4">
          You must not reproduce, distribute, modify, create derivative works of, publicly display, publicly perform, 
          republish, download, store, or transmit any of the material on our Website, except as follows:
        </p>
        <ul className="list-disc list-inside text-gray-300 space-y-2 ml-4">
          <li>Your computer may temporarily store copies of such materials in RAM incidental to your accessing and viewing those materials.</li>
          <li>You may store files that are automatically cached by your Web browser for display enhancement purposes.</li>
          <li>You may print or download one copy of a reasonable number of pages of the Website for your own personal, non-commercial use and not for further reproduction, publication, or distribution.</li>
        </ul>
      </section>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">5. Prohibited Uses</h2>
        <p className="text-gray-300 mb-4">
          You may use the Website only for lawful purposes and in accordance with these Terms. You agree not to use the Website:
        </p>
        <ul className="list-disc list-inside text-gray-300 space-y-2 ml-4">
          <li>In any way that violates any applicable federal, state, local, or international law or regulation.</li>
          <li>To transmit, or procure the sending of, any advertising or promotional material, including any "junk mail," "chain letter," "spam," or any other similar solicitation.</li>
          <li>To impersonate or attempt to impersonate SleekMath, a SleekMath employee, another user, or any other person or entity.</li>
          <li>To engage in any other conduct that restricts or inhibits anyone's use or enjoyment of the Website, or which may harm SleekMath or users of the Website.</li>
        </ul>
      </section>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">6. Disclaimer of Warranties</h2>
        <p className="text-gray-300 mb-4">
          You understand that we cannot and do not guarantee or warrant that files available for downloading from the internet 
          or the Website will be free of viruses or other destructive code. You are responsible for implementing sufficient 
          procedures and checkpoints to satisfy your particular requirements for anti-virus protection and accuracy of data 
          input and output, and for maintaining a means external to our site for any reconstruction of any lost data.
        </p>
        <p className="text-gray-300 mb-4 uppercase font-bold">
          To the fullest extent provided by law, we will not be liable for any loss or damage caused by a distributed 
          denial-of-service attack, viruses, or other technologically harmful material that may infect your computer 
          equipment, computer programs, data, or other proprietary material due to your use of the website or any services 
          or items obtained through the website or to your downloading of any material posted on it, or on any website linked to it.
        </p>
        <p className="text-gray-300 mb-4 uppercase font-bold">
          Your use of the website, its content, and any services or items obtained through the website is at your own risk. 
          The website, its content, and any services or items obtained through the website are provided on an "as is" and 
          "as available" basis, without any warranties of any kind, either express or implied.
        </p>
      </section>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">7. Limitation on Liability</h2>
        <p className="text-gray-300 mb-4 uppercase font-bold">
          To the fullest extent provided by law, in no event will SleekMath, its affiliates, or their licensors, service providers, 
          employees, agents, officers, or directors be liable for damages of any kind, under any legal theory, arising out of or 
          in connection with your use, or inability to use, the website, any websites linked to it, any content on the website or 
          such other websites, including any direct, indirect, special, incidental, consequential, or punitive damages.
        </p>
      </section>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">8. Indemnification</h2>
        <p className="text-gray-300 mb-4">
          You agree to defend, indemnify, and hold harmless SleekMath, its affiliates, licensors, and service providers, 
          and its and their respective officers, directors, employees, contractors, agents, licensors, suppliers, successors, 
          and assigns from and against any claims, liabilities, damages, judgments, awards, losses, costs, expenses, or fees 
          (including reasonable attorneys' fees) arising out of or relating to your violation of these Terms or your use of the Website.
        </p>
      </section>
      
      <section className="mb-8">
        <h2 className="text-2xl text-blue-300 mb-4">9. Governing Law and Jurisdiction</h2>
        <p className="text-gray-300 mb-4">
          All matters relating to the Website and these Terms, and any dispute or claim arising therefrom or related thereto, 
          shall be governed by and construed in accordance with the internal laws of the State of [Your State] without giving 
          effect to any choice or conflict of law provision or rule.
        </p>
        <p className="text-gray-300 mb-4">
          Any legal suit, action, or proceeding arising out of, or related to, these Terms or the Website shall be instituted 
          exclusively in the federal courts of the United States or the courts of the State of [Your State], although we retain 
          the right to bring any suit, action, or proceeding against you for breach of these Terms in your country of residence 
          or any other relevant country.
        </p>
      </section>
      
      <section>
        <h2 className="text-2xl text-blue-300 mb-4">10. Contact Information</h2>
        <p className="text-gray-300 mb-4">
          If you have any questions about these Terms, please contact us at:
        </p>
        <p className="text-blue-400">terms@sleekmath.com</p>
      </section>
    </div>
  );
}
