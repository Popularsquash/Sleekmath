'use client';

import BasicCalculator from '@/components/calculators/BasicCalculator';
import { Inter, Poppins, Roboto_Mono } from 'next/font/google';
import Link from 'next/link';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });
const poppins = Poppins({ 
  weight: ['400', '500', '600', '700'],
  subsets: ['latin'],
  variable: '--font-poppins'
});
const robotoMono = Roboto_Mono({ 
  subsets: ['latin'],
  variable: '--font-roboto-mono'
});

export default function Home() {
  return (
    <main className={`min-h-screen py-8 px-4 ${inter.variable} ${poppins.variable} ${robotoMono.variable} font-sans`}>
      <div className="max-w-6xl mx-auto">
        <header className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-center font-poppins bg-gradient-to-r from-[#00FFFF] to-[#9D00FF] text-transparent bg-clip-text">
            Sleek Calculator
          </h1>
          <p className="text-center text-gray-300 mt-2">
            A modern, black-themed calculator with advanced functionality
          </p>
          <nav className="mt-6">
            <ul className="flex flex-wrap justify-center gap-2 md:gap-4">
              <li>
                <Link href="/" className="px-4 py-2 bg-[#1E1E1E] rounded-full text-[#00FFFF] hover:bg-[#2a2a2a] transition-colors">
                  Basic
                </Link>
              </li>
              <li>
                <Link href="/scientific" className="px-4 py-2 bg-[#1E1E1E] rounded-full text-white hover:bg-[#2a2a2a] transition-colors">
                  Scientific
                </Link>
              </li>
              <li>
                <Link href="/financial" className="px-4 py-2 bg-[#1E1E1E] rounded-full text-white hover:bg-[#2a2a2a] transition-colors">
                  Financial
                </Link>
              </li>
              <li>
                <Link href="/bmi" className="px-4 py-2 bg-[#1E1E1E] rounded-full text-white hover:bg-[#2a2a2a] transition-colors">
                  BMI
                </Link>
              </li>
              <li>
                <Link href="/unit-converter" className="px-4 py-2 bg-[#1E1E1E] rounded-full text-white hover:bg-[#2a2a2a] transition-colors">
                  Converter
                </Link>
              </li>
              <li>
                <Link href="/ai-solver" className="px-4 py-2 bg-[#1E1E1E] rounded-full text-white hover:bg-[#2a2a2a] transition-colors">
                  AI Solver
                </Link>
              </li>
            </ul>
          </nav>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-8 lg:col-start-3">
            <BasicCalculator />
          </div>
        </div>

        <footer className="mt-12 text-center text-gray-400 text-sm">
          <p>© 2025 Sleek Calculator. All rights reserved.</p>
          <div className="mt-2 flex justify-center gap-4">
            <Link href="/about" className="hover:text-[#00FFFF] transition-colors">About</Link>
            <Link href="/privacy" className="hover:text-[#00FFFF] transition-colors">Privacy</Link>
            <Link href="/terms" className="hover:text-[#00FFFF] transition-colors">Terms</Link>
          </div>
        </footer>
      </div>
    </main>
  );
}
